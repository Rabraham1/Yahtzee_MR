﻿using System;

namespace Yahtzee_Project
{
    class Program
    {
        static void Main(string[] args)
        {
            // variables
            bool playGame = true;
            string menuCommand = "";

            // game loop
            while (playGame)
            {
                menuCommand = DisplayMenu();

                switch (menuCommand.ToUpper())
                {
                    case "X":
                        playGame = false;
                        break;
                    default:
                        PlayYahtzee();
                        break;
                }

            }
        }
        static string DisplayMenu()
        {
            {
                string menuCommand = "";


                Console.WriteLine("");
                Console.WriteLine("YAHTZEE");
                Console.WriteLine("");
                Console.WriteLine("- roll the 5 dice to start the round");
                Console.WriteLine("- press 'Enter' to play");
                Console.WriteLine("- press 'X' to exit");
                Console.WriteLine("");

                menuCommand = Console.ReadLine();
                return menuCommand;
            }
        }

        private static void PlayYahtzee()
        {
            int[] player1 = new int[6];
            Random rnd = new Random();
            Console.Clear();


            for (int i = 0; i<5; i++)
            {
                System.Threading.Thread.Sleep(300); //"rolling" dice effect on numbers 
                int diceRoll = 0;

                diceRoll = rnd.Next(6); // 5 random numbers instead of 1
                player1[diceRoll]++;
                Console.WriteLine("\n{0}", diceRoll + 1);
            }
        }
    }
}